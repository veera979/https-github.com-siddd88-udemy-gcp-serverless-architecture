
gcloud functions deploy fetch_wishlist_count --runtime python310 \
--trigger-http --allow-unauthenticated