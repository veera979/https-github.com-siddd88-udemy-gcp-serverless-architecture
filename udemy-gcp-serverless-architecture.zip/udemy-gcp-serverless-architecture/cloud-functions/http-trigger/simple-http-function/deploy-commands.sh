# APIs to be enabled 
- cloud function 
- cloud build 
- eventarc
- cloud run admin api 
- artifact registry 

gcloud functions deploy http_func --runtime python310 ≈ --allow-unauthenticated